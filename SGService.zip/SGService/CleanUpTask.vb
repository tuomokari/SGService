﻿Public Class CleanUpTask
    Public Sub New(task As SGService.Settings.Task)
        Try
            For Each CU As Settings.CleanupSetting In task.CleanUpSettingList
                'SearchOption.TopDirectoryOnly
            Next
        Catch ex As Exception
            task.Result.Success = False
            task.Result.ProcessError = ex.Message
        End Try

    End Sub
End Class
