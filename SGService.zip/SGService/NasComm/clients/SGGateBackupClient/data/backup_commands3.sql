BACKUP DATABASE justus2021_test_db TO DISK = N'E:\Systemsgarden\sites\justus2021_test\database\backup.bak'
WITH NOFORMAT, INIT,  NAME = N'justus2021_test_db Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10

GO