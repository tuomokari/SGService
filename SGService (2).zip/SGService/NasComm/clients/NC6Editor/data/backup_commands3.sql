BACKUP DATABASE alfons2021_test_db TO DISK = N'E:\Systemsgarden\sites\alfons2021_test\database\backup.bak'
WITH NOFORMAT, INIT,  NAME = N'alfons2021_test_db Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10

GO